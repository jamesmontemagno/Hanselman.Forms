﻿using System;

namespace $safeprojectname$.Portable
{
    public class Scott
    {
        public Scott()
        {
        }
    }
}

