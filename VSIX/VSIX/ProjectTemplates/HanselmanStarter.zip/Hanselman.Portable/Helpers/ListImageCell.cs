﻿using System;
using Xamarin.Forms;

namespace $safeprojectname$.Portable
{
    public class ListImageCell : ImageCell { }
}