﻿using System;
using Xamarin.Forms;

namespace Hanselman.Portable
{
    public class ListImageCell : ImageCell { }
}