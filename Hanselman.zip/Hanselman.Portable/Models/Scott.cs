﻿using System;

namespace Hanselman.Portable
{
    public class Scott
    {
        public Scott()
        {
        }
    }
}

